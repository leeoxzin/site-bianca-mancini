import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import useEmblaCarousel from "embla-carousel-react";
import {
  Brain, ClipboardList, Activity, Compass, HeartHandshake,
  MapPin, Instagram, Linkedin, ChevronDown, ChevronLeft, ChevronRight,
  ShieldCheck, Sparkles, Users, Leaf, Monitor, Home,
  Check, Lock, Clock, Menu, X, Maximize2,
} from "lucide-react";
import aboutImg from "@/assets/bianca-retrato.jpg.asset.json";
import logoAsset from "@/assets/logo-bianca-mancini.png.asset.json";
import salaHeroAsset from "@/assets/sala-essencia-01.png.asset.json";
import recepcao01 from "@/assets/espaco/recepcao-01.jpg.asset.json";
import recepcaoCafe from "@/assets/espaco-novo/recepcao-espaco-cafe.jpeg.asset.json";
import recepcaoPiscina from "@/assets/espaco-novo/recepcao-piscina-de-bolinhas.jpeg.asset.json";
import recepcaoEspera from "@/assets/espaco-novo/recepcao-sala-de-espera.jpeg.asset.json";
import mundoEntrada from "@/assets/espaco-novo/sala-mundo-das-descobertas.jpeg.asset.json";
import mundoBrinquedos from "@/assets/espaco-novo/brinquedos-mundo-das-descobertas.jpeg.asset.json";
import mundoBrinquedos02 from "@/assets/espaco-novo/brinquedos2-mundo-das-descobertas.jpeg.asset.json";
import essenciaAmbiente from "@/assets/espaco-novo/sala-essencia.jpeg.asset.json";
import essenciaMesa from "@/assets/espaco-novo/sala-essencia2.jpeg.asset.json";
import essenciaDetalhe from "@/assets/espaco-novo/sala-essencia3.jpeg.asset.json";
import especTcc from "@/assets/especialidades/tcc.jpg";
import especAba from "@/assets/especialidades/aba.jpg";
import especParental from "@/assets/especialidades/parental.jpg";
import especNeuroAval from "@/assets/especialidades/neuro-avaliacao.jpg";
import especAvalPsi from "@/assets/especialidades/avaliacao-psi.jpg";
import especReab from "@/assets/especialidades/reabilitacao.jpg";
import especVocacional from "@/assets/especialidades/vocacional.jpg";

type SpacePhoto = { url: string; title: string; caption: string };
type SpaceArea = { name: string; intro: string; photos: SpacePhoto[] };
const spaceAreas: SpaceArea[] = [
  {
    name: "Recepção",
    intro: "Um acolhimento cuidadoso desde a chegada, para que cada pessoa se sinta segura e bem recebida.",
    photos: [
      { url: recepcao01.url, title: "Chegada e atendimento", caption: "Na entrada, nossa recepcionista realiza o acolhimento, o check-in e a confirmação do atendimento com atenção e discrição." },
      { url: recepcaoCafe.url, title: "Espaço do café", caption: "Enquanto aguarda, cada paciente pode aproveitar nosso espaço de café, chá e bolachas, preparado para tornar esse momento mais confortável." },
    ],
  },
  {
    name: "Sala de Espera",
    intro: "Conforto para adultos, famílias e crianças enquanto aguardam o início do atendimento.",
    photos: [
      { url: recepcaoEspera.url, title: "Ambiente de espera", caption: "Poltronas confortáveis, livros e um pequeno espaço infantil compõem um ambiente tranquilo para aguardar o chamado da psicóloga." },
      { url: recepcaoPiscina.url, title: "Espaço lúdico", caption: "A piscina de bolinhas e os brinquedos ajudam as crianças a se sentirem à vontade e acolhidas desde os primeiros momentos na clínica." },
    ],
  },
  {
    name: "Sala Mundo das Descobertas",
    intro: "Um ambiente lúdico e estruturado para favorecer expressão, vínculo e novas descobertas.",
    photos: [
      { url: mundoEntrada.url, title: "Mundo das Descobertas", caption: "A entrada apresenta um espaço criado especialmente para o atendimento infantil, onde brincar também é uma forma de comunicar e aprender." },
      { url: mundoBrinquedos.url, title: "Brinquedos e recursos terapêuticos", caption: "Jogos, brinquedos e painéis sensoriais apoiam intervenções planejadas, estimulando habilidades cognitivas, emocionais, sociais e motoras." },
      { url: mundoBrinquedos02.url, title: "Brincar com propósito", caption: "A diversidade de materiais permite que cada encontro seja adaptado às necessidades da criança, respeitando seu ritmo, seus interesses e sua singularidade." },
    ],
  },
  {
    name: "Sala Essência",
    intro: "Privacidade, serenidade e conforto para uma escuta verdadeiramente atenta e individualizada.",
    photos: [
      { url: essenciaAmbiente.url, title: "Acolhimento e conforto", caption: "Um espaço reservado e acolhedor, pensado para favorecer segurança emocional, conexão e liberdade durante a sessão." },
      { url: essenciaMesa.url, title: "Atendimento individualizado", caption: "A mesa de atendimento e os recursos clínicos apoiam avaliações e acompanhamentos conduzidos com organização, ética e atenção a cada história." },
      { url: essenciaDetalhe.url, title: "Um espaço para cuidar", caption: "Cada detalhe foi escolhido para criar uma atmosfera tranquila, com privacidade e conforto para o processo terapêutico." },
    ],
  },
];

const WHATSAPP_URL = "https://api.whatsapp.com/message/5CZFWA5HQP52N1?autoload=1&app_absent=0&utm_source=ig";
const INSTAGRAM_URL = "https://www.instagram.com/psi.biamancini/";
const TIKTOK_URL = "https://www.tiktok.com/@psi.biamancini?lang=pt-BR";
const LINKEDIN_URL = "https://www.linkedin.com/in/bianca-nigro/";
const ADDRESS = "Rua Dr. Carlos Afrânio da Cunha Matos, 2 – Sala 26, São Paulo – SP, 05140-040";

const SEO_TITLE = "Bianca Mancini | Psicóloga em São Paulo | TCC, ABA e Neuropsicologia";
const SEO_DESC = "Bianca Mancini – Psicóloga CRP 06/215079. Atendimento psicológico presencial em São Paulo e online. Especialista em TCC, ABA, Orientação Parental, Avaliação Neuropsicológica e Orientação Vocacional.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: SEO_TITLE },
      { name: "description", content: SEO_DESC },
      { name: "keywords", content: "psicóloga em São Paulo, psicóloga TCC, psicóloga ABA, orientação parental, avaliação neuropsicológica, avaliação psicológica, reabilitação neuropsicológica, orientação vocacional, terapia online, psicóloga online" },
      { property: "og:title", content: SEO_TITLE },
      { property: "og:description", content: SEO_DESC },
      { property: "og:url", content: "/" },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: SEO_TITLE },
      { name: "twitter:description", content: SEO_DESC },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Psychologist",
          name: "Bianca Mancini",
          description: SEO_DESC,
          identifier: "CRP 06/215079",
          areaServed: "São Paulo",
          medicalSpecialty: ["Psychology", "Neuropsychology", "Cognitive Behavioral Therapy"],
          address: {
            "@type": "PostalAddress",
            streetAddress: "Rua Dr. Carlos Afrânio da Cunha Matos, 2 – Sala 26",
            addressLocality: "São Paulo",
            addressRegion: "SP",
            postalCode: "05140-040",
            addressCountry: "BR",
          },
          sameAs: [INSTAGRAM_URL],
        }),
      },
    ],
  }),
  component: HomePage,
});

// Official WhatsApp icon
function WhatsAppIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="currentColor" className={className} aria-hidden="true">
      <path d="M19.11 17.205c-.372 0-1.088 1.39-1.518 1.39a.63.63 0 0 1-.315-.1c-.802-.402-1.504-.817-2.163-1.447-.545-.516-1.146-1.29-1.46-1.963a.426.426 0 0 1-.073-.215c0-.33.99-.945.99-1.49 0-.143-.73-2.09-.832-2.335-.143-.372-.214-.487-.6-.487-.187 0-.36-.043-.53-.043-.302 0-.53.115-.746.315-.688.645-1.032 1.318-1.06 2.264v.114c-.015.99.472 1.977 1.017 2.78 1.23 1.82 2.506 3.41 4.554 4.34.616.287 2.035.945 2.722.945.46 0 2.392-.43 2.392-1.776 0-.227-.014-.27-.144-.487-.115-.187-.36-.302-.6-.43.272.444-1.135-.717-1.633-.717zm-2.74 7.79h-.014a9.852 9.852 0 0 1-4.96-1.353l-.358-.214-3.687.97.983-3.592-.23-.37a9.815 9.815 0 0 1-1.504-5.21c.002-5.432 4.428-9.854 9.875-9.854 2.64 0 5.117 1.026 6.98 2.892a9.795 9.795 0 0 1 2.89 6.97c-.002 5.434-4.43 9.857-9.875 9.857zm8.398-18.234A11.793 11.793 0 0 0 16.366 3.31C9.832 3.31 4.514 8.626 4.51 15.16c-.001 2.09.546 4.13 1.585 5.93L4.41 27.097l6.16-1.62a11.85 11.85 0 0 0 5.795 1.497h.005c6.532 0 11.85-5.318 11.852-11.852A11.81 11.81 0 0 0 24.77 6.762z" />
    </svg>
  );
}

// TikTok brand icon
function TikTokIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
    </svg>
  );
}



const specialties = [
  {
    icon: Brain,
    image: especTcc,
    title: "Terapia Cognitivo-Comportamental (TCC)",
    desc: "Abordagem baseada em evidências que integra pensamentos, emoções e comportamentos. Através de técnicas estruturadas, ajudamos você a identificar padrões que causam sofrimento e a construir novas formas de lidar com desafios do dia a dia — com clareza, autonomia e resultados duradouros.",
  },
  {
    icon: Sparkles,
    image: especAba,
    title: "ABA — Análise do Comportamento Aplicada",
    desc: "Intervenção clínica fundamentada em princípios científicos da análise do comportamento, com aplicação especializada em crianças com TEA e atrasos no desenvolvimento. Trabalhamos habilidades sociais, comunicação e autonomia por meio de um plano individualizado, mensurável e ético.",
  },
  {
    icon: HeartHandshake,
    image: especParental,
    title: "Orientação Parental",
    desc: "Espaço de escuta e construção de estratégias para pais e cuidadores. Abordamos manejo de comportamento, comunicação, limites afetivos e desafios específicos do desenvolvimento infantil — fortalecendo o vínculo familiar e promovendo relações mais equilibradas em casa.",
  },
  {
    icon: ClipboardList,
    image: especNeuroAval,
    title: "Avaliação Neuropsicológica",
    desc: "Investigação aprofundada das funções cognitivas — atenção, memória, linguagem, funções executivas — associada a aspectos emocionais e comportamentais. O resultado é um laudo detalhado que orienta diagnóstico, planejamento terapêutico e decisões escolares ou clínicas.",
  },
  {
    icon: Activity,
    image: especAvalPsi,
    title: "Avaliação Psicológica",
    desc: "Processo técnico e criterioso para compreensão do funcionamento psicológico. Utilizamos instrumentos validados e entrevistas clínicas para apoiar decisões em contextos clínicos, educacionais e profissionais — com sigilo, ética e devolutiva humanizada.",
  },
  {
    icon: Leaf,
    image: especReab,
    title: "Reabilitação Neuropsicológica",
    desc: "Intervenções voltadas à recuperação e ao fortalecimento das funções cognitivas comprometidas por quadros neurológicos, psiquiátricos ou do desenvolvimento. Um plano personalizado que devolve autonomia, funcionalidade e qualidade de vida.",
  },
  {
    icon: Compass,
    image: especVocacional,
    title: "Orientação Vocacional",
    desc: "Um percurso reflexivo para escolhas profissionais mais conscientes. Cruzamos interesses, habilidades, valores e história pessoal para que jovens e adultos encontrem direções coerentes com quem são — e não apenas com o que se espera deles.",
  },
];


const featuredSpecialties = specialties.slice(0, 3);
const otherSpecialties = specialties.slice(3);


const modalities = [
  {
    icon: Home,
    tag: "No consultório",
    title: "Atendimento Presencial",
    subtitle: "Consultório em São Paulo — Zona Oeste",
    description:
      "Um espaço pensado para acolher com discrição e conforto, favorecendo a escuta atenta e o vínculo terapêutico.",
    items: [
      "Ambiente reservado e silencioso",
      "Atendimento individualizado",
      "Fácil acesso a região - Próximo a estação/terminal Pirituba",
      "Estrutura completa para acolhimento",
    ],
    meta: [
      { label: "Duração", value: "50 minutos" },
      { label: "Frequência", value: "Semanal" },
      { label: "Formato", value: "Individual" },
    ],
    featured: true,
  },
  {
    icon: Monitor,
    tag: "Onde você estiver",
    title: "Atendimento Online",
    subtitle: "De qualquer lugar do Brasil ou do mundo",
    description:
      "A mesma qualidade clínica do presencial, com a praticidade de uma plataforma segura e sigilosa.",
    items: [
      "Plataforma criptografada e sigilosa",
      "Sem deslocamento, no conforto da sua casa",
      "Flexibilidade de horários",
      "Link da reunião enviado no WhatsApp",
    ],
    meta: [
      { label: "Duração", value: "50 minutos" },
      { label: "Frequência", value: "Semanal" },
      { label: "Formato", value: "Videochamada" },
    ],
    featured: false,
  },
];

const processSteps = [
  { n: "01", t: "Contato inicial", d: "Você envia uma mensagem pelo WhatsApp e conversamos sobre sua demanda." },
  { n: "02", t: "Agendamento", d: "Definimos juntos a modalidade, horário e a primeira sessão." },
  { n: "03", t: "Acolhimento", d: "Iniciamos o processo terapêutico em ambiente sigiloso e ético." },
  { n: "04", t: "Continuidade", d: "Acompanhamento contínuo com revisão periódica de objetivos." },
];

const faqs = [
  { q: "Como funciona a terapia?", a: "A terapia é um processo colaborativo entre você e a psicóloga. Nos encontros, trabalhamos pensamentos, emoções e comportamentos com técnicas baseadas em evidências, em um ambiente acolhedor e sigiloso." },
  { q: "Qual a duração das sessões?", a: "Cada sessão tem duração média de 50 minutos, com frequência geralmente semanal — ajustada conforme suas necessidades clínicas." },
  { q: "O atendimento online funciona?", a: "Sim. Estudos científicos comprovam a eficácia da terapia online. Realizada por videoconferência segura, oferece flexibilidade sem comprometer a qualidade." },
  { q: "Qual o valor da sessão?", a: "Os valores são informados diretamente pelo WhatsApp, de forma personalizada conforme a modalidade e a frequência do acompanhamento." },
  { q: "Atende por convênio?", a: "O atendimento é particular, mas emitimos recibo detalhado para que você possa solicitar reembolso junto ao seu plano de saúde, conforme as regras da sua operadora." },
  { q: "A partir de qual idade atende crianças?", a: "O atendimento infantil é realizado a partir dos 2 anos de idade, com abordagem lúdica. Para um acompanhamento completo, personalizado e individual, a “ORIENTAÇÃO PARENTAL” é um serviço incluso no pacote." },
  { q: "Quais formas de pagamento são aceitas?", a: "Aceitamos PIX, transferência bancária e cartão de crédito. Emitimos recibo para reembolso em planos de saúde." },
  { q: "Como funciona a avaliação neuropsicológica?", a: "É um processo de alto conhecimento que envolve entrevistas, aplicação de testes padronizados e elaboração de laudo." },
  { q: "Qual é o nosso público alvo?", a: "Nosso público-alvo é amplo e diversificado, abrangendo desde crianças a partir de 2 anos, adolescentes e famílias, até adultos e idosos. " },
];

function useCarousel(opts?: Parameters<typeof useEmblaCarousel>[0]) {
  const [emblaRef, embla] = useEmblaCarousel({ align: "start", loop: true, ...opts });
  const [selected, setSelected] = useState(0);
  const [snaps, setSnaps] = useState<number[]>([]);
  const scrollPrev = useCallback(() => embla?.scrollPrev(), [embla]);
  const scrollNext = useCallback(() => embla?.scrollNext(), [embla]);
  const scrollTo = useCallback((i: number) => embla?.scrollTo(i), [embla]);
  useEffect(() => {
    if (!embla) return;
    const onSelect = () => setSelected(embla.selectedScrollSnap());
    setSnaps(embla.scrollSnapList());
    embla.on("select", onSelect);
    embla.on("reInit", () => setSnaps(embla.scrollSnapList()));
    onSelect();
  }, [embla]);
  return { emblaRef, scrollPrev, scrollNext, scrollTo, selected, snaps };
}

function SpaceAreaCarousel({ area, areaIndex, onOpen }: { area: SpaceArea; areaIndex: number; onOpen: (areaIndex: number, photoIndex: number) => void }) {
  const carousel = useCarousel({ align: "start", loop: true });
  const selectedPhoto = area.photos[carousel.selected] ?? area.photos[0];

  return (
    <article className="grid items-center gap-6 border-t border-border py-7 sm:py-9 lg:grid-cols-2 lg:gap-12">
      <div className={`min-w-0 ${areaIndex % 2 === 1 ? "lg:order-2" : ""}`}>
        <div className="relative mx-auto w-full max-w-[380px] overflow-hidden rounded-xl border border-border bg-secondary/50" ref={carousel.emblaRef}>
          <div className="flex">
            {area.photos.map((photo, photoIndex) => (
              <div key={photo.url} className="relative flex-[0_0_100%] min-w-0 aspect-square bg-secondary/40">
                <img src={photo.url} alt={photo.title} className="h-full w-full object-cover" loading="lazy" />
                <button
                  type="button"
                  onClick={() => onOpen(areaIndex, photoIndex)}
                  className="absolute bottom-3 right-3 inline-flex items-center gap-2 rounded-full border border-border bg-background/95 px-4 py-2.5 text-xs font-medium text-foreground shadow-md backdrop-blur-sm transition hover:border-primary hover:text-primary sm:bottom-4 sm:right-4"
                  aria-label={`Ampliar ${photo.title}`}
                >
                  <Maximize2 className="h-4 w-4" />
                  Ampliar
                </button>
              </div>
            ))}
          </div>
          {area.photos.length > 1 && (
            <>
              <button type="button" onClick={carousel.scrollPrev} aria-label={`Imagem anterior de ${area.name}`} className="absolute left-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full border border-border bg-background/95 text-foreground shadow-sm transition hover:border-primary">
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button type="button" onClick={carousel.scrollNext} aria-label={`Próxima imagem de ${area.name}`} className="absolute right-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full border border-border bg-background/95 text-foreground shadow-sm transition hover:border-primary">
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          )}
        </div>
        <div className="mt-2 flex flex-wrap justify-center gap-1">
          {carousel.snaps.map((_, photoIndex) => (
            <button key={photoIndex} type="button" onClick={() => carousel.scrollTo(photoIndex)} className="grid h-10 w-8 place-items-center" aria-label={`Ver foto ${photoIndex + 1} de ${area.name}`}>
              <span className={`block h-2 rounded-full transition ${photoIndex === carousel.selected ? "w-7 bg-primary" : "w-2 bg-border"}`} />
            </button>
          ))}
        </div>
      </div>

      <div className={areaIndex % 2 === 1 ? "lg:order-1" : ""}>
        <div className="flex items-center gap-3 text-[11px] font-medium uppercase tracking-[0.2em] text-primary">
          <span>{String(areaIndex + 1).padStart(2, "0")}</span>
          <span className="h-px w-10 bg-primary/40" />
          <span>{String(carousel.selected + 1).padStart(2, "0")} / {String(area.photos.length).padStart(2, "0")}</span>
        </div>
        <h3 className="mt-4 font-display text-2xl text-foreground sm:text-3xl">{area.name}</h3>
        <p className="mt-3 text-sm leading-7 text-muted-foreground sm:text-base">{area.intro}</p>
        <div className="mt-6 border-l-2 border-primary pl-5">
          <p className="font-medium text-foreground">{selectedPhoto.title}</p>
          <p className="mt-2 text-sm leading-7 text-muted-foreground sm:text-[15px]">{selectedPhoto.caption}</p>
        </div>
      </div>
    </article>
  );
}

function HomePage() {
  const [lgpdAccepted, setLgpdAccepted] = useState(true);
  useEffect(() => { setLgpdAccepted(localStorage.getItem("lgpd_consent") === "1"); }, []);
  const acceptLgpd = () => { localStorage.setItem("lgpd_consent", "1"); setLgpdAccepted(true); };
  const declineLgpd = () => { localStorage.setItem("lgpd_consent", "0"); setLgpdAccepted(true); };

  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [spaceOpen, setSpaceOpen] = useState(false);
  const [spaceAreaIdx, setSpaceAreaIdx] = useState(0);
  const [spaceIdx, setSpaceIdx] = useState(0);
  const activeSpaceArea = spaceAreas[spaceAreaIdx] ?? spaceAreas[0];
  const activeSpacePhotos = activeSpaceArea.photos;
  const nextSpace = useCallback(() => setSpaceIdx((i) => (i + 1) % activeSpacePhotos.length), [activeSpacePhotos.length]);
  const prevSpace = useCallback(() => setSpaceIdx((i) => (i - 1 + activeSpacePhotos.length) % activeSpacePhotos.length), [activeSpacePhotos.length]);
  const openSpace = (areaIndex: number, photoIndex: number) => {
    setSpaceAreaIdx(areaIndex);
    setSpaceIdx(photoIndex);
    setSpaceOpen(true);
  };
  useEffect(() => {
    if (!spaceOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSpaceOpen(false);
      if (e.key === "ArrowRight") nextSpace();
      if (e.key === "ArrowLeft") prevSpace();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [spaceOpen, nextSpace, prevSpace]);

  // Bloqueia o scroll do fundo quando o menu ou a galeria estão abertos (mobile)
  useEffect(() => {
    const lock = spaceOpen || menuOpen;
    document.body.style.overflow = lock ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [spaceOpen, menuOpen]);


  const navLinks = [
    { href: "#sobre", label: "Sobre" },
    { href: "#especialidades", label: "Especialidades" },
    { href: "#atendimento", label: "Atendimento" },
    { href: "#localizacao", label: "Localização" },
    { href: "#faq", label: "FAQ" },
    { href: "#contato", label: "Contato" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* NAV */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-navy/95 border-b border-white/10 text-white">
        <div className="container-narrow flex h-14 sm:h-16 items-center justify-between gap-3">
          <a href="#top" className="flex items-center gap-2 font-display text-lg sm:text-xl tracking-tight shrink-0 text-white">
            <img
              src={logoAsset.url}
              alt="Logo Bianca Mancini"
              className="h-8 w-8 sm:h-9 sm:w-9 object-contain"
              loading="eager"
              width={1024}
              height={1024}
            />
            <span>Bianca <span className="text-primary">Mancini</span></span>
          </a>
          <nav className="hidden lg:flex items-center gap-7 text-sm text-white/70">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="hover:text-white transition">{l.label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
              className="btn-primary !py-2 !px-3 sm:!px-5 text-xs sm:text-sm">
              <WhatsAppIcon className="h-4 w-4" />
              <span className="hidden sm:inline">Agendar</span>
            </a>
            <button onClick={() => setMenuOpen(true)} aria-label="Abrir menu"
              className="lg:hidden h-10 w-10 grid place-items-center rounded-full border border-white/25 text-white">
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* MOBILE MENU */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button aria-label="Fechar" onClick={() => setMenuOpen(false)}
            className="absolute inset-0 bg-foreground/40 backdrop-blur-sm" />
          <aside className="absolute right-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto overscroll-contain bg-background border-l border-border p-6 flex flex-col animate-fade-up">
            <div className="flex items-center justify-between">
              <span className="font-display text-lg">Menu</span>
              <button onClick={() => setMenuOpen(false)} aria-label="Fechar menu"
                className="h-10 w-10 grid place-items-center rounded-full border border-border">
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="mt-8 flex flex-col gap-1">
              {navLinks.map((l) => (
                <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)}
                  className="py-3 px-2 text-base border-b border-border/60 text-foreground/90 hover:text-primary transition">
                  {l.label}
                </a>
              ))}
            </nav>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
              onClick={() => setMenuOpen(false)} className="btn-primary mt-8">
              <WhatsAppIcon className="h-4 w-4" /> Falar no WhatsApp
            </a>
            <p className="mt-auto text-xs text-muted-foreground pt-6">CRP 06/215079 · Sigilo absoluto</p>
          </aside>
        </div>
      )}

      {/* HERO – editorial sem retrato */}
      <section id="top" className="relative overflow-hidden">
        {/* imagem de fundo: sala de atendimento */}
        <img
          src={salaHeroAsset.url}
          alt="Sala de atendimento da psicóloga Bianca Mancini em São Paulo"
          className="absolute inset-0 w-full h-full object-cover object-center"
          loading="eager"
        />
        {/* overlays de legibilidade */}
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/92 to-background/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-background/85 via-transparent to-background/40" />
        <div className="absolute inset-0 bg-secondary/20 mix-blend-multiply" />

        <div className="container-narrow relative pt-12 pb-14 sm:pt-24 sm:pb-28 lg:pt-32 lg:pb-36">
          <div className="z-10 animate-fade-up max-w-3xl">
            {/* TEXTO */}
              <div className="inline-flex items-center gap-3 mb-5 sm:mb-8">
                <span className="h-px w-8 sm:w-10 bg-primary" />
                <span className="text-[10px] sm:text-xs tracking-[0.24em] sm:tracking-[0.28em] uppercase text-primary font-medium">CLINICA MULTIDISCIPLINAR</span>
              </div>
              <h1 className="font-display text-[1.9rem] min-[400px]:text-[2.15rem] sm:text-5xl md:text-6xl lg:text-7xl xl:text-[5.5rem] leading-[1.1] sm:leading-[1.02] tracking-tight text-foreground [text-wrap:balance] break-words">
                Espaço onde o cuidar é&nbsp;<em className="not-italic text-primary italic font-medium">reencontrar</em>{" "}<br className="hidden sm:block" />
                <span className="text-foreground/70">a sua identidade.</span>
              </h1>
              <p className="mt-6 sm:mt-10 text-[15px] sm:text-lg text-muted-foreground leading-relaxed max-w-xl">
                Cuidado multidisciplinar guiado pela ciência, pela ética e pela humanidade.&nbsp;Ciência para compreender. Ética para conduzir. Humanidade para cuidar.
              </p>

              <div className="mt-7 sm:mt-10 flex flex-col sm:flex-row sm:flex-wrap items-start sm:items-center gap-y-2.5 sm:gap-y-3 sm:gap-x-8 text-[13px] sm:text-sm text-foreground/75">
                <div className="flex items-center gap-2"><Check className="h-4 w-4 text-primary shrink-0" /> Atendimento online e presencial</div>
                <div className="flex items-center gap-2"><Lock className="h-4 w-4 text-primary shrink-0" /> Sigilo profissional garantido</div>
              </div>
          </div>
        </div>
      </section>

      {/* SOBRE — editorial premium */}
      <section id="sobre" className="section-pad bg-card">
        <div className="container-narrow">
          {/* Citação de destaque */}
          <div className="max-w-3xl mx-auto text-center mb-14 sm:mb-20">
            <span className="eyebrow">Sobre</span>
            <div className="w-12 h-px bg-primary mx-auto mt-6" />
            <blockquote className="mt-10 font-display text-2xl sm:text-3xl md:text-[2.25rem] italic font-light text-foreground/85 leading-[1.35]">
              “Acredito em um cuidado psicológico individualizado, que respeita a história e a singularidade de cada pessoa. Um olhar humano e acolhedor, aliado à ciência, para além de diagnósticos e rótulos.”
            </blockquote>
          </div>

          {/* Conteúdo principal */}
          <div className="grid gap-12 lg:gap-20 lg:grid-cols-[0.95fr_1fr] lg:items-stretch">
            {/* Foto com legenda */}
            <figure className="relative">
              <div className="relative h-full rounded-[1.75rem] overflow-hidden shadow-[0_28px_80px_-32px_color-mix(in_oklab,var(--foreground)_22%,transparent)] ring-1 ring-border">
                <img
                  src={aboutImg.url}
                  alt="Bianca Mancini, psicóloga clínica em São Paulo"
                  loading="lazy"
                  className="w-full aspect-[4/5] lg:absolute lg:inset-0 lg:aspect-auto lg:h-full lg:w-full object-cover"
                  style={{ objectPosition: "50% 28%" }}
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/90 via-background/40 to-transparent p-6 pt-20">
                  <p className="font-display text-lg text-foreground">Bianca Mancini</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Psicóloga Clínica · CRP 06/215079</p>
                </div>
              </div>
            </figure>

            {/* Texto e credenciais */}
            <div className="space-y-8 sm:space-y-10">
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-primary font-medium mb-3">Prazer, sou</p>
                <h2 className="font-display text-3xl sm:text-4xl md:text-5xl text-foreground leading-[1.05]">Bianca Mancini</h2>
                <p className="mt-4 text-muted-foreground text-base sm:text-lg leading-relaxed">
                  Psicóloga e Neuropsicóloga (CRP 06/215079) com experiência em desenvolvimento emocional, comportamental e cognitivo. Minha prática é guiada 
                  com conhecimento científico e atenção a cada história
                  — porque cada história merece um cuidado único.
                </p>
                <p className="mt-4 text-muted-foreground text-base sm:text-lg leading-relaxed">
                  O processo terapêutico é uma construção em parceria. Ofereço um espaço seguro onde você possa se desenvolver, ressignificar experiências e encontrar caminhos para uma vida mais plena.
                </p>
              </div>

              {/* CTA */}
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-primary border-b border-primary pb-1 hover:opacity-80 transition">
                Conhecer meu trabalho no WhatsApp →
              </a>

              {/* Formação e credenciais */}
              <div className="bg-background rounded-2xl border border-border/70 p-6 sm:p-7">
                <p className="text-xs uppercase tracking-[0.2em] text-primary font-medium">ESPECIALIDADES</p>
                <ul className="mt-4 space-y-3">
                  {[
                    "CRP Ativo — CRP 06/215079",
                    "Terapia Cognitivo-Comportamental — TCC",
                    "Análise do Comportamento Aplicada — ABA",
                    "Avaliação e Reabilitação Neuropsicológica",
                    "Atendimento Infantil",
                    "Transtorno do Espectro Autista — TEA",
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-sm sm:text-[15px] text-foreground/85">
                      <span className="mt-1 grid h-5 w-5 place-items-center rounded-full bg-primary/10 shrink-0">
                        <Check className="h-3 w-3 text-primary" strokeWidth={3} />
                      </span>
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ESPECIALIDADES – GRID EDITORIAL */}
      <section id="especialidades" className="section-pad bg-background font-esp-body">
        <div className="container-narrow">
          <div className="mb-14 text-center sm:mb-16">
            <span className="mb-3 block text-xs font-semibold uppercase tracking-[0.22em] text-esp-gold">
              Serviços Clínicos
            </span>
            <h2 className="font-esp text-4xl font-medium text-esp-blue sm:text-5xl md:text-6xl">
              Especialidades
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-esp-blue/70 sm:text-lg">
              Abordagens integradas para diferentes momentos da vida — sempre com escuta atenta e técnica baseada em evidências.
            </p>
          </div>

          {/* Especialidades principais */}
          <div className="mb-16 grid gap-6 sm:mb-20 sm:grid-cols-2 sm:gap-8 lg:grid-cols-3">
            {featuredSpecialties.map(({ title, desc }) => (
              <article
                key={title}
                className="group flex h-full flex-col border-t-4 border-esp-gold bg-card p-6 shadow-sm transition-all duration-500 hover:shadow-xl sm:p-8 lg:p-10"
              >
                <h3 className="mb-5 font-esp text-2xl font-medium leading-snug text-esp-blue sm:text-3xl">
                  {title}
                </h3>
                <p className="mb-8 flex-grow text-sm leading-relaxed text-esp-blue/80 sm:text-[15px]">
                  {desc}
                </p>
                <a
                  href={WHATSAPP_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 w-fit items-center gap-2 text-sm font-medium tracking-wide text-esp-gold transition-all hover:underline"
                >
                  Saber mais
                  <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2} />
                </a>
              </article>
            ))}
          </div>

          {/* Outras áreas de atuação */}
          <div className="border-t border-esp-sand pt-12">
            <h4 className="mb-8 text-center text-sm font-semibold uppercase tracking-[0.22em] text-esp-blue/60">
              Outras áreas de atuação
            </h4>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {otherSpecialties.map(({ title }) => (
                <a
                  key={title}
                  href={WHATSAPP_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center border border-esp-sand bg-esp-sand/30 p-6 text-center transition-colors hover:border-esp-gold"
                >
                  <p className="text-sm font-medium text-esp-blue md:text-base">{title}</p>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* MODALIDADES + PROCESSO + LOCALIZAÇÃO */}
      <section id="atendimento" className="section-pad bg-secondary/40">
        <div className="container-narrow">
          {/* Cabeçalho */}
          <div className="max-w-3xl">
            <span className="eyebrow">Modalidades de atendimento</span>
            <h2 className="mt-4 text-2xl sm:text-3xl md:text-4xl lg:text-5xl">
              Um cuidado clínico que se adapta à sua rotina
            </h2>
            <p className="mt-5 text-base sm:text-lg text-muted-foreground leading-relaxed max-w-2xl">
              Escolha entre encontros presenciais em São Paulo ou sessões online com a mesma qualidade,
              ética e sigilo. Em ambas as modalidades, o cuidado é individualizado e baseado em evidências.
            </p>
          </div>

          {/* Cards de modalidades */}
          <div className="mt-12 sm:mt-16 grid gap-6 sm:gap-8 lg:grid-cols-2">
            {modalities.map(({ icon: Icon, tag, title, subtitle, description, items, meta, featured }, idx) => (
              <article
                key={title}
                className={`relative flex flex-col rounded-3xl border p-6 sm:p-8 lg:p-10 transition-shadow hover:shadow-lg ${
                  featured
                    ? "bg-card border-primary/20 shadow-md"
                    : "bg-background border-border"
                }`}
              >
                {/* Número editorial */}
                <div className="flex items-start justify-between gap-3 sm:gap-4">
                  <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                    <div className={`h-12 w-12 sm:h-14 sm:w-14 rounded-2xl grid place-items-center shrink-0 ${
                      featured ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"
                    }`}>
                      <Icon className="h-6 w-6 sm:h-7 sm:w-7" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[10px] sm:text-[11px] tracking-[0.18em] uppercase text-muted-foreground">
                        {tag}
                      </span>
                      <h3 className="mt-1 text-xl sm:text-2xl lg:text-[1.7rem] font-display leading-tight">
                        {title}
                      </h3>
                    </div>
                  </div>
                  <span className="hidden sm:block font-display text-3xl text-muted-foreground/40 tabular-nums shrink-0">
                    0{idx + 1}
                  </span>
                </div>

                <p className="mt-6 text-sm sm:text-base text-muted-foreground leading-relaxed">
                  {subtitle} — {description}
                </p>

                {/* Lista de benefícios */}
                <ul className="mt-7 space-y-3.5">
                  {items.map((i) => (
                    <li key={i} className="flex items-start gap-3 text-sm sm:text-[15px] text-foreground/85">
                      <span className="mt-1 grid h-5 w-5 place-items-center rounded-full bg-primary/10 shrink-0">
                        <Check className="h-3 w-3 text-primary" strokeWidth={3} />
                      </span>
                      <span className="leading-relaxed">{i}</span>
                    </li>
                  ))}
                </ul>

                {/* Meta info */}
                <div className="mt-8 pt-6 border-t border-border/70 grid grid-cols-2 gap-4 sm:grid-cols-3">
                  {meta.map((m) => (
                    <div key={m.label}>
                      <div className="text-[10px] tracking-[0.16em] uppercase text-muted-foreground">
                        {m.label}
                      </div>
                      <div className="mt-1 text-sm sm:text-base font-medium text-foreground">
                        {m.value}
                      </div>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <a
                  href={WHATSAPP_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`mt-8 inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium transition ${
                    featured
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "border border-border bg-background hover:border-primary hover:text-primary"
                  }`}
                >
                  <WhatsAppIcon className="h-4 w-4" /> Agendar nesta modalidade
                </a>
              </article>
            ))}
          </div>

          {/* Localização */}
          <div id="localizacao" className="mt-20 scroll-mt-16 sm:scroll-mt-20 sm:mt-24">

            <div className="max-w-2xl">
              <span className="eyebrow">Localização</span>
              <h3 className="mt-3 text-xl sm:text-2xl md:text-3xl font-display">
                Onde nos encontramos
              </h3>
            </div>

            <div className="mt-10 grid gap-6 sm:gap-8 lg:grid-cols-[1fr_1.3fr] items-stretch">
              <div className="rounded-3xl bg-background border border-border p-7 sm:p-9 flex flex-col">
                <div className="flex items-center gap-2 text-[11px] tracking-[0.18em] uppercase text-muted-foreground">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Consultório
                </div>
                <h4 className="mt-3 font-display text-xl sm:text-2xl">São Paulo — Zona Oeste</h4>

                <div className="mt-6 space-y-5">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                    <div className="text-sm sm:text-[15px] text-foreground/85 leading-relaxed">
                      Rua Dr. Carlos Afrânio da Cunha Matos, 2 — Sala 26<br />
                      <span className="text-muted-foreground">São Paulo — SP, 05140-040</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                    <div className="text-sm sm:text-[15px] text-foreground/85 leading-relaxed">
                      Segunda a sexta — 08h às 20h<br />
                      Sábado&nbsp;— 08h às 15h<br />
                      <span className="text-muted-foreground">Atendimento somente com hora marcada</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                    <div className="text-sm sm:text-[15px] text-foreground/85 leading-relaxed">
                      Ambiente sigiloso e acessível<br />
                      <span className="text-muted-foreground">Estacionamento na região</span>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-border/70 flex flex-wrap gap-3">
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-5 py-2.5 text-sm font-medium hover:bg-primary/90 transition"
                  >
                    <MapPin className="h-4 w-4" /> Abrir no Google Maps
                  </a>
                  <a
                    href={WHATSAPP_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-medium hover:border-primary hover:text-primary transition"
                  >
                    <WhatsAppIcon className="h-4 w-4" /> Falar pelo WhatsApp
                  </a>
                </div>
              </div>

              <div className="relative overflow-hidden rounded-3xl border border-border min-h-[340px] sm:min-h-[420px]">
                <iframe
                  title="Localização do consultório Bianca Mancini"
                  src={`https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}&output=embed`}
                  width="100%"
                  height="100%"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0 h-full w-full"
                  style={{ border: 0, filter: "grayscale(40%) contrast(0.95)" }}
                />
              </div>
            </div>
          </div>
          {/* Conheça nosso espaço */}
          <section id="espaco" className="mt-16 border-y border-border bg-background px-4 py-10 sm:mt-20 sm:px-6 sm:py-14 lg:py-16">
            <div className="mx-auto w-full max-w-6xl">
              <div className="mx-auto max-w-3xl text-center">
                <span className="text-[11px] font-medium uppercase tracking-[0.22em] text-primary">NOSSO ESPAÇO</span>
                <h2 className="mt-5 font-display text-[1.75rem] leading-[1.15] text-foreground sm:text-3xl md:text-4xl lg:text-[2.75rem]">
                  Ambientes pensados para cada etapa do cuidado
                </h2>
                <p className="mt-5 text-[15px] leading-7 text-muted-foreground sm:text-base md:text-[17px]">
                  Da chegada ao atendimento, cada ambiente foi preparado para oferecer acolhimento, segurança e conforto a crianças, famílias e adultos.
                </p>
              </div>

              <div className="mt-10 sm:mt-14">
                {spaceAreas.map((area, areaIndex) => (
                  <SpaceAreaCarousel key={area.name} area={area} areaIndex={areaIndex} onOpen={openSpace} />
                ))}
              </div>
            </div>
          </section>


          {/* Como funciona — processo */}
          <div className="mt-20 sm:mt-24">
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div className="max-w-xl">
                <span className="eyebrow">Como funciona</span>
                <h3 className="mt-3 text-xl sm:text-2xl md:text-3xl font-display">
                  Quatro passos simples até a sua primeira sessão
                </h3>
              </div>
              <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4 text-primary" />
                <span>Resposta em até 24h úteis</span>
              </div>
            </div>

            <ol className="mt-10 grid gap-px bg-border rounded-3xl overflow-hidden sm:grid-cols-2 lg:grid-cols-4">
              {processSteps.map((s) => (
                <li key={s.n} className="bg-background p-7 sm:p-8 flex flex-col">
                  <span className="font-display text-3xl text-primary tabular-nums">{s.n}</span>
                  <h4 className="mt-4 text-base sm:text-lg font-medium text-foreground">{s.t}</h4>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.d}</p>
                </li>
              ))}
            </ol>
          </div>

        </div>
      </section>




      {/* FAQ */}
      <section id="faq" className="section-pad">
        <div className="container-narrow max-w-3xl">
          <div className="text-center">
            <span className="eyebrow">FAQ</span>
            <h2 className="mt-4 text-2xl sm:text-3xl md:text-4xl lg:text-5xl">Perguntas frequentes</h2>
          </div>
          <div className="mt-10 sm:mt-12 divide-y divide-border border-y border-border">
            {faqs.map((f, i) => {
              const open = openFaq === i;
              return (
                <div key={f.q}>
                  <button onClick={() => setOpenFaq(open ? null : i)}
                    className="w-full flex items-center justify-between gap-4 py-4 sm:py-5 text-left" aria-expanded={open}>
                    <span className="font-display text-lg sm:text-xl font-semibold text-foreground pr-2">{f.q}</span>
                    <ChevronDown className={`h-5 w-5 text-primary shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
                  </button>
                  <div className={`grid transition-all duration-300 ${open ? "grid-rows-[1fr] pb-5" : "grid-rows-[0fr]"}`}>
                    <div className="overflow-hidden">
                      <p className="text-sm sm:text-base text-muted-foreground leading-relaxed pr-2 sm:pr-8">{f.a}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CONTATO – profissional */}
      <section id="contato" className="relative section-pad overflow-hidden">
        <div className="absolute inset-0 -z-10"
          style={{ background: "linear-gradient(180deg, var(--background), color-mix(in oklab, var(--primary) 8%, var(--background)))" }} />
        <div className="container-narrow">
          <div className="max-w-2xl mx-auto text-center">
            <span className="eyebrow">Entre em contato</span>
            <h2 className="mt-4 text-2xl sm:text-3xl md:text-5xl leading-tight">Pronta para acolher a sua história</h2>
            <p className="mt-4 sm:mt-5 text-muted-foreground leading-relaxed">
              O primeiro contato é simples e sem compromisso. Escolha o canal de sua preferência —
              respondo pessoalmente para alinharmos o melhor horário e modalidade para você.
            </p>
          </div>

          <div className="mt-10 sm:mt-14 grid gap-4 sm:gap-5 grid-cols-1 md:grid-cols-3 max-w-5xl mx-auto">
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-7 sm:p-8 hover:border-primary/40 transition-all duration-300">
              <WhatsAppIcon className="h-8 w-8 text-primary" />
              <h3 className="mt-6 font-display text-lg sm:text-xl">WhatsApp</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Atendimento direto e ágil para tirar dúvidas e agendar sua consulta.
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary">
                Enviar mensagem <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </span>
            </a>

            <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-7 sm:p-8 hover:border-primary/40 transition-all duration-300">
              <Instagram className="h-8 w-8 text-primary" strokeWidth={1.5} />
              <h3 className="mt-6 font-display text-lg sm:text-xl">Instagram</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Conteúdos sobre psicologia, comportamento e desenvolvimento emocional.
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary">
                @psi.biamancini <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </span>
            </a>

            <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-7 sm:p-8 hover:border-primary/40 transition-all duration-300">
              <TikTokIcon className="h-8 w-8 text-primary" />
              <h3 className="mt-6 font-display text-lg sm:text-xl">TikTok</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Conteúdos rápidos e leves sobre psicologia, comportamento e bem-estar.
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary">
                @psi.biamancini <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </span>
            </a>

            <a href={LINKEDIN_URL} target="_blank" rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-7 sm:p-8 hover:border-primary/40 transition-all duration-300">
              <Linkedin className="h-8 w-8 text-primary" strokeWidth={1.5} />
              <h3 className="mt-6 font-display text-lg sm:text-xl">LinkedIn</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Conteúdos sobre psicologia, saúde mental e desenvolvimento profissional.
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary">
                Bianca Nigro <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </span>
            </a>


            <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS)}`}
              target="_blank" rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-7 sm:p-8 hover:border-primary/40 transition-all duration-300">
              <MapPin className="h-8 w-8 text-primary" strokeWidth={1.5} />
              <h3 className="mt-6 font-display text-lg sm:text-xl">Clínica</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Rua Dr. Carlos Afrânio da Cunha Matos, 2 — Sala 26, São Paulo/SP.
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary">
                Abrir no Google Maps <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </span>
            </a>
          </div>


          {/* Banner CTA sage */}
          <div className="mt-14 sm:mt-20 max-w-5xl mx-auto relative overflow-hidden rounded-[1.5rem] sm:rounded-[2rem] bg-primary text-primary-foreground p-7 sm:p-12 lg:p-14 text-center">
            <div className="absolute -top-24 -left-24 w-64 h-64 rounded-full bg-white/5" />
            <div className="absolute -bottom-32 -right-24 w-80 h-80 rounded-full bg-foreground/10" />
            <div className="relative z-10">
              <h2 className="font-display text-2xl sm:text-4xl md:text-5xl leading-tight">Pronto para começar?</h2>
              <p className="mt-4 sm:mt-5 text-sm sm:text-base text-primary-foreground/85 max-w-md mx-auto leading-relaxed">
                O primeiro passo é sempre o mais importante. Envie uma mensagem no WhatsApp e
                vamos conversar sobre o melhor caminho para você.
              </p>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                className="mt-6 sm:mt-8 inline-flex items-center gap-3 bg-background text-primary px-7 sm:px-9 py-3.5 sm:py-4 rounded-full text-sm sm:text-base font-semibold hover:opacity-95 transition shadow-xl">
                <WhatsAppIcon className="h-5 w-5" /> Agendar via WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-navy-deep text-white/85">
        <div className="container-narrow py-10 sm:py-14 grid gap-8 sm:gap-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
          <div>
            <div className="font-display text-xl text-white">Bianca <span className="text-primary">Mancini</span></div>
            <p className="mt-2 text-sm text-white/60">Psicóloga Clínica · CRP 06/215079</p>
            <p className="mt-4 text-sm text-white/70 max-w-sm leading-relaxed">
              Atendimento psicológico humanizado, presencial em São Paulo e online para todo o Brasil.
            </p>
          </div>
          <div>
            <div className="text-sm font-medium text-white">Links rápidos</div>
            <ul className="mt-2 text-sm text-white/65">
              <li><a href="#top" className="inline-flex min-h-10 items-center hover:text-primary transition">Início</a></li>
              <li><a href="#sobre" className="inline-flex min-h-10 items-center hover:text-primary transition">Sobre</a></li>
              <li><a href="#especialidades" className="inline-flex min-h-10 items-center hover:text-primary transition">Especialidades</a></li>
              <li><a href="#atendimento" className="inline-flex min-h-10 items-center hover:text-primary transition">Atendimento</a></li>
              <li><a href="#localizacao" className="inline-flex min-h-10 items-center hover:text-primary transition">Localização</a></li>
              <li><a href="#contato" className="inline-flex min-h-10 items-center hover:text-primary transition">Contato</a></li>
            </ul>
          </div>
          <div className="sm:col-span-2 md:col-span-1">
            <div className="text-sm font-medium text-white">Conecte-se</div>
            <div className="mt-2 flex flex-wrap gap-2">
              <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                className="grid h-11 w-11 place-items-center rounded-full text-primary transition hover:bg-white/10">
                <Instagram className="h-5 w-5" strokeWidth={1.5} />
              </a>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"
                className="grid h-11 w-11 place-items-center rounded-full text-primary transition hover:bg-white/10">
                <WhatsAppIcon className="h-5 w-5" />
              </a>
              <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer" aria-label="TikTok"
                className="grid h-11 w-11 place-items-center rounded-full text-primary transition hover:bg-white/10">
                <TikTokIcon className="h-5 w-5" />
              </a>
              <a href={LINKEDIN_URL} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"
                className="grid h-11 w-11 place-items-center rounded-full text-primary transition hover:bg-white/10">
                <Linkedin className="h-5 w-5" strokeWidth={1.5} />
              </a>
            </div>
            <p className="mt-6 text-xs text-white/50">
              © {new Date().getFullYear()} Bianca Mancini. Todos os direitos reservados.
            </p>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="container-narrow py-5 flex items-center justify-center gap-2 text-xs text-white/50">
            <span>Desenvolvido por:</span>
            <span className="font-medium text-white/75">LN Tech</span>
          </div>
        </div>
      </footer>

      {/* Space Gallery Lightbox */}
      {spaceOpen && (
        <div className="fixed inset-0 z-[60] bg-navy-deep/95 backdrop-blur-md flex flex-col animate-fade-up" role="dialog" aria-modal="true" aria-label="Galeria do consultório">
          <div className="flex items-center justify-between gap-3 px-4 sm:px-8 py-4 border-b border-white/10 text-white">
            <div className="min-w-0">
              <div className="text-[10px] sm:text-[11px] tracking-[0.22em] uppercase text-primary font-medium">
                {activeSpaceArea.name} · {String(spaceIdx + 1).padStart(2, "0")} / {String(activeSpacePhotos.length).padStart(2, "0")}
              </div>
              <div className="mt-1 truncate font-display text-lg sm:text-2xl">{activeSpacePhotos[spaceIdx]?.title}</div>
            </div>
            <button onClick={() => setSpaceOpen(false)} aria-label="Fechar galeria"
              className="h-10 w-10 shrink-0 sm:h-11 sm:w-11 grid place-items-center rounded-full border border-white/25 hover:bg-white/10 transition">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 min-h-0 relative flex items-center justify-center px-3 sm:px-16 py-4 sm:py-6">
            <button onClick={prevSpace} aria-label="Anterior"
              className="absolute left-3 sm:left-8 top-1/2 -translate-y-1/2 h-11 w-11 sm:h-12 sm:w-12 grid place-items-center rounded-full bg-white/10 hover:bg-primary text-white transition z-10">
              <ChevronLeft className="h-5 w-5" />
            </button>
            <div className="relative max-h-full max-w-5xl w-full h-full flex items-center justify-center">
              <img
                key={activeSpacePhotos[spaceIdx]?.url}
                src={activeSpacePhotos[spaceIdx]?.url}
                alt={activeSpacePhotos[spaceIdx]?.title}
                className="max-h-[68vh] sm:max-h-[72vh] w-auto max-w-full rounded-2xl object-contain shadow-2xl animate-fade-up"
              />
            </div>
            <button onClick={nextSpace} aria-label="Próximo"
              className="absolute right-3 sm:right-8 top-1/2 -translate-y-1/2 h-11 w-11 sm:h-12 sm:w-12 grid place-items-center rounded-full bg-white/10 hover:bg-primary text-white transition z-10">
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

          <div className="px-4 sm:px-8 pb-4 text-center">
            <p className="max-w-2xl mx-auto text-sm text-white/75 leading-relaxed">
              {activeSpacePhotos[spaceIdx]?.caption}
            </p>
          </div>

          <div className="px-4 sm:px-8 pb-6 border-t border-white/10 pt-4 overflow-x-auto">
            <div className="flex gap-3 justify-start sm:justify-center min-w-max mx-auto">
              {activeSpacePhotos.map((p, i) => (
                <button
                  key={p.url}
                  onClick={() => setSpaceIdx(i)}
                  className={`relative h-16 w-20 sm:h-20 sm:w-28 shrink-0 rounded-lg overflow-hidden transition ring-2 ${
                    i === spaceIdx ? "ring-primary opacity-100" : "ring-transparent opacity-55 hover:opacity-100"
                  }`}
                  aria-label={p.title}
                >
                  <img src={p.url} alt={p.title} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}



      {/* Floating WhatsApp */}
      <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" aria-label="Falar no WhatsApp"
        className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 h-12 w-12 sm:h-14 sm:w-14 rounded-full grid place-items-center text-white shadow-2xl shadow-primary/20 animate-float-pulse"
        style={{ backgroundColor: "#25D366" }}>
        <WhatsAppIcon className="h-6 w-6 sm:h-7 sm:w-7" />
      </a>

      {/* LGPD */}
      {!lgpdAccepted && (
        <div className="fixed bottom-4 left-4 right-4 md:right-auto md:max-w-md z-50 bg-card border border-border rounded-2xl shadow-2xl p-5 animate-fade-up">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Utilizamos cookies para melhorar sua experiência e analisar o tráfego do site, em conformidade com a LGPD.
          </p>
          <div className="mt-4 flex gap-2">
            <button onClick={acceptLgpd} className="btn-primary !py-2 !px-4 text-sm">Aceitar</button>
            <button onClick={declineLgpd} className="btn-ghost !py-2 !px-4 text-sm">Recusar</button>
          </div>
        </div>
      )}
    </div>
  );
}
