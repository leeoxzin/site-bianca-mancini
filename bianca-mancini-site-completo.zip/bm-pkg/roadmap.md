# Roadmap

- [x] Redesenhar seção Especialidades — direção "Editorial sofisticado" (azul profundo & dourado, Cormorant Garamond + Karla, grade de cards) implementada e verificada em desktop e mobile.
